#include "AlnParser.h"

float LogPoissonTailProb(float n, float lambda);

float LogPoissonPDF(float k, float lambda);

float LAdd(float x, float y);
